package handler

import (
	"com.bugTrack/api/repo"
	"com.bugTrack/api/shared"
	"encoding/base64"
	"fmt"
	"github.com/gin-gonic/gin"
	"strconv"
	"strings"
)

func Authenticate() gin.HandlerFunc{
	return func (context *gin.Context) {

		encodedCredentials := context.GetHeader("Authorization")
		credString, err0 := base64.StdEncoding.DecodeString(encodedCredentials)

		if err0 != nil {
			fmt.Errorf("error while decoding creds: %s", err0)
			context.IndentedJSON(401, []string{})
			return
		}

		credentials := strings.Split(string(credString), ":")

		if len(credentials) != 2 {
			fmt.Errorf("creds array length invalid")
			context.IndentedJSON(401, []string{})
			return
		}

		username := credentials[0]
		password := credentials[1]

		result, err1 := repo.Authenticate(username, password)

		if err1 != nil {
			fmt.Errorf("wrong username, password: %s", err1)
			context.IndentedJSON(401, []string{})
			return
		}
		context.IndentedJSON(200, result)
	}

}

func CreateUser() gin.HandlerFunc{
	return func(context *gin.Context) {
		var user shared.User
		context.BindJSON(&user)

		id, err := repo.CreateUser(user)

		if err != nil {
			context.IndentedJSON(500, nil)
			return
		}

		context.IndentedJSON(201, id)
	}
}

func GetUser() gin.HandlerFunc{
	return func (context *gin.Context) {

		userId, _ := strconv.Atoi(context.Param("id"))

		user, err := repo.GetUser(userId)

		if err != nil {
			context.IndentedJSON(400, nil)
			return
		}
		context.IndentedJSON(200, user)
	}
}

func GetUserByUsername() gin.HandlerFunc{
	return func (context *gin.Context) {

		username := context.Param("username")

		user, err := repo.GetUserByUsername(username)

		if err != nil {
			context.IndentedJSON(400, nil)
			return
		}
		context.IndentedJSON(200, user)
	}
}

func UpdateUser() gin.HandlerFunc{
	return func (context *gin.Context) {
		var user shared.User

		context.BindJSON(&user)

		context.IndentedJSON(200, repo.Update(user))
	}
}