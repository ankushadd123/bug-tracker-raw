package handler

import (
	"com.bugTrack/api/repo"
	"com.bugTrack/api/shared"
	"github.com/gin-gonic/gin"
	"strconv"
)

func GetPeople() gin.HandlerFunc{
	return func (context *gin.Context) {
		context.IndentedJSON(200, repo.GetPeople())
	}
}

func CreatePerson() gin.HandlerFunc{
	return func (context *gin.Context) {
		var person shared.Person
		context.BindJSON(&person)

		id, err := repo.CreatePerson(person)

		if err != nil {
			context.IndentedJSON(500, nil)
			return
		}

		context.IndentedJSON(201, id)
	}
}

func GetPerson() gin.HandlerFunc{
	return func (context *gin.Context){

		id, _ := strconv.Atoi(context.Param("id"))

		person, err := repo.GetPerson(id)

		if err != nil {
			context.IndentedJSON(500, nil)
			return
		}
		context.IndentedJSON(200, person)
	}
}

func UpdatePerson() gin.HandlerFunc{
	return func (context *gin.Context){

		var person shared.Person

		context.BindJSON(&person)

		isSuccess := repo.UpdatePerson(person)

		context.IndentedJSON(200, isSuccess)
	}
}