package handler

import (
	"com.bugTrack/api/repo"
	"com.bugTrack/api/shared"
	"fmt"
	"strconv"
)
import "github.com/gin-gonic/gin"

func CreateBugHandler() gin.HandlerFunc {
	return func (context *gin.Context) {
		var bug shared.BugRequest
		context.BindJSON(&bug)
		newBug := repo.Create(bug)
		if newBug.Id == 0 {
			fmt.Println("writing 400")
			context.Status(400)
			return
		}
		context.IndentedJSON(201, &newBug)
	}
}

func GetBugsHandler() gin.HandlerFunc {
	return func (context *gin.Context) {
		bugs := repo.Get()
		if len(bugs) == 0 {
			context.IndentedJSON(200, []string{})
			return
		}
		context.IndentedJSON(200, bugs)
	}
}

func UpdateBugStatusHandler() gin.HandlerFunc {
	return func (context *gin.Context) {
		var bug shared.BugStatusRequest
		context.BindJSON(&bug)
		result := repo.UpdateStatus(bug.Id, bug.UpdatedStatus)
		context.IndentedJSON(200, result)
	}
}

func UpdateBugAssignee() gin.HandlerFunc {
	return func (context *gin.Context) {
		var bug shared.BugOverview
		context.BindJSON(&bug)
		result := repo.UpdateAssignee(bug.Id, bug.AssignedTo)
		context.IndentedJSON(200, result)
	}
}

func UpdateBug() gin.HandlerFunc {
	return func (context *gin.Context) {
		var bug shared.BugOverview
		context.BindJSON(&bug)
		result := repo.UpdateBug(bug)
		context.IndentedJSON(200, result)
	}
}

func DeleteBug() gin.HandlerFunc {
	return func (context *gin.Context) {
		bugId, _ := strconv.Atoi(context.Param("id"))
		result := repo.DeleteBug(bugId)
		context.IndentedJSON(200, result)
	}
}