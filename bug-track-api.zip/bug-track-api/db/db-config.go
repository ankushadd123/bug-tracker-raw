package db

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"os"
)
import "com.bugTrack/api/shared"

var dbConfig shared.DBConfig

func getConnection() *sql.DB{
	//<username>:<pw>@tcp(<HOST>:<port>)/<dbname>"
	dataSourceUrl := dbConfig.Username + ":" + dbConfig.Password + "@tcp(" + dbConfig.Host + ":" + dbConfig.Port + ")" + "/" + "tracker"
	connection, err0 := sql.Open("mysql", dataSourceUrl)
	if err0 != nil {
		fmt.Println("Error opening connection to db: ", err0)
		os.Exit(1)
	}
	return connection
}

func ConfigureDB(properties shared.ApplicationProperties) {
	dbConfig = properties.DBConfig
}
