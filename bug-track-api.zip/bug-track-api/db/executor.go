package db

import (
	"database/sql"
	"fmt"
)

func Select(query string) (*sql.Rows, error) {
	connection := getConnection()

	rows, err0 := connection.Query(query)
	connection.Close()

	if err0 != nil {
		return nil, err0
	}
	return rows, nil
}

func Execute(query string) (sql.Result, error){
	fmt.Println(query)
	connection := getConnection()
	result, err := connection.Exec(query)
	connection.Close()

	if err != nil {
		return nil, err
	}
	return result, nil
}
