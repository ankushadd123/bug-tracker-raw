package main

import (
	"com.bugTrack/api/api"
	"com.bugTrack/api/db"
	"com.bugTrack/api/shared"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
)

func main() {

	applicationProperties := loadProperties()
	db.ConfigureDB(applicationProperties)

	api.ExposeEndpoints()
}

func loadProperties() shared.ApplicationProperties {
	propertiesFile, err := os.Open("application.json")

	if err != nil {
		fmt.Println("Error reading application properties: ", err)
		os.Exit(1)
	}

	content, err := ioutil.ReadAll(propertiesFile)
	if err != nil {
		fmt.Println(err)
	}

	var applicationProperties shared.ApplicationProperties

	err = json.Unmarshal(content, &applicationProperties)
	if err != nil {
		fmt.Println(err)
	}

	propertiesFile.Close()

	return applicationProperties
}