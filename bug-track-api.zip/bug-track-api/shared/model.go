package shared

type BugRequest struct {
	Name string `json:"name"`
	Description string `json:"description"`
	AssignedTo int `json:"assigned_to"`
	CreatedBy int `json:"created_by"`
}

type Bug struct {
	BugOverview
	CreatedBy int `json:"created_by"`
	CreatedAt string `json:"created_at"`
	UpdatedAt string `json:"updated_at"`
}

type BugStatusRequest struct {
	Id int `json:"id"`
	UpdatedStatus string `json:"status"`
}

type BugOverview struct {
	Id int `json:"id"`
	Name string `json:"name"`
	Description string `json:"description"`
	Status string `json:"status"`
	AssignedTo int `json:"assigned_to"`
}

type DBConfig struct {
		Host string `json:"host"`
		Port string	`json:"port"`
		Username string	`json:"username"`
		Password string `json:"password"`
}

type ApplicationProperties struct {
	DBConfig DBConfig `json:"db"`
}

type Person struct {
	Id int `json:"id"`
	Name string `json:"name"`
	Role string `json:"role"`
}

type User struct {
	Id int `json:"id"`
	Username string `json:"username"`
	Email string `json:"email"`
	Password string `json:"password"`
	PersonId int `json:"personId"`
}