package api

import (
	"com.bugTrack/api/shared"
	"github.com/gin-gonic/gin"
)
import "com.bugTrack/api/handler"

func ExposeEndpoints() {

	context := gin.Default()
	context.Use(shared.SetCors())

	context.POST("/api/bug", handler.CreateBugHandler())
	context.GET("/api/bug", handler.GetBugsHandler())
	context.PUT("/api/bug", handler.UpdateBug())
	context.DELETE("/api/bug/:id", handler.DeleteBug())
	context.PUT("/api/bug/status", handler.UpdateBugStatusHandler())
	context.PUT("/api/bug/assignee", handler.UpdateBugAssignee())

	context.POST("/api/authenticate", handler.Authenticate())

	context.GET("/api/people", handler.GetPeople())

	context.POST("/api/person", handler.CreatePerson())
	context.POST("/api/user", handler.CreateUser())

	context.GET("/api/person/:id", handler.GetPerson())
	context.GET("api/user/v1/:id", handler.GetUser())
	context.GET("/api/user/v2/:username", handler.GetUserByUsername())

	context.PUT("/api/person", handler.UpdatePerson())
	context.PUT("/api/user", handler.UpdateUser())


	context.Run(":8082")
}
