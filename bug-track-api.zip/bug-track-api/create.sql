mysql> create table bug(
    -> id int auto_increment,
    -> name varchar(100) not null,
    -> description varchar(500) null,
    -> created_by varchar(30),
    -> created_at datetime,
    -> assigned_to varchar(30),
    -> primary key(id)
    -> );