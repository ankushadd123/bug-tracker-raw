package repo

import (
	"com.bugTrack/api/db"
	"com.bugTrack/api/shared"
	"errors"
)
import "fmt"

func Authenticate(username string, password string) (shared.User, error){

	query := fmt.Sprintf("SELECT id, username, person_id FROM user WHERE (email = '%s' OR username = '%s') AND password = '%s' LIMIT 1",
										username, username, password)
	fmt.Println(query)
	row, error := db.Select(query)

	if error != nil {
		msg := fmt.Errorf("Some error occured while authentication: %s ", error)
		fmt.Println(msg.Error())
		return shared.User{}, error
	}
	var user shared.User
	for row.Next() {
		row.Scan(&user.Id, &user.Username, &user.PersonId)
		return user, nil
	}
	return shared.User{}, errors.New("invalid user")
}

func CreateUser(user shared.User) (int, error) {

	fmt.Println(user)

	query :=
		fmt.Sprintf("INSERT INTO user(username, email, password, person_id) VALUES ('%s', '%s', '%s', %d);",
			user.Username, user.Email, user.Password, user.PersonId)

	output, err := db.Execute(query)
	fmt.Println(err)

	if err != nil {
		return 0, err
	}

	id, _ := output.LastInsertId()

	return int(id), nil
}

func GetUser(id int) (shared.User, error) {
	query := fmt.Sprintf("SELECT * FROM user WHERE id = %d;", id)
	return get(query)
}

func GetUserByUsername(username string) (shared.User, error) {
	query := fmt.Sprintf("SELECT * FROM user WHERE username = '%s';", username)
	return get(query)
}

func get(query string) (shared.User, error) {

	rows, err := db.Select(query)

	var user shared.User

	if err != nil {
		return user, err
	}

	for rows.Next() {
		rows.Scan(&user.Id, &user.Username, &user.Email, &user.Password, &user.PersonId)
	}
	return user, nil
}

func Update(user shared.User) bool {

	query := fmt.Sprintf("UPDATE user SET username = '%s', email = '%s', password = '%s' WHERE id = %d;",
		user.Username, user.Email, user.Password, user.Id)

	_, err := db.Execute(query)

	if err != nil {
		fmt.Println(err)
		return false
	}

	return true
}