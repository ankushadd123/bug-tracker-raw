package repo

import (
	"com.bugTrack/api/db"
	"com.bugTrack/api/shared"
	"testing"
)

func Test_Authenticate(t *testing.T) {
	dbConfig := shared.DBConfig{
		Host:     "localhost",
		Port:     "3306",
		Username: "root",
		Password: "root",
	}
	db.ConfigureDB(shared.ApplicationProperties{
		DBConfig: dbConfig,
	})

	Authenticate("admin", "YWRtaW4=")
}
