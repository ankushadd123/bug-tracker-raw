package repo

import (
	"com.bugTrack/api/db"
	"com.bugTrack/api/shared"
	"testing"
)

func setUpTest() {
	dbConfig := shared.DBConfig{
	Host:     "localhost",
	Port:     "3306",
	Username: "root",
	Password: "root",
	}
	db.ConfigureDB(shared.ApplicationProperties{
	DBConfig: dbConfig,
	})
}
func Test_GetPerson(t *testing.T) {
	setUpTest()
	GetPerson(2)
}

func Test_GetPeople(t *testing.T) {
	setUpTest()
	GetPeople()
}
