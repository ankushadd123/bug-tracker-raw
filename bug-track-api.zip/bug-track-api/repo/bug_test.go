package repo

import (
	"com.bugTrack/api/db"
	"com.bugTrack/api/shared"
	"fmt"
	"testing"
)

func Test_Create(t *testing.T) {
	dbConfig := shared.DBConfig{
		Host:     "localhost",
		Port:     "3306",
		Username: "root",
		Password: "root",
	}
	db.ConfigureDB(shared.ApplicationProperties{
		DBConfig: dbConfig,
	})
	var bugs []shared.Bug
	bugs = append(bugs, shared.Bug{
		Name:        "name1",
		Description: "desc1",
		CreatedBy:   "ank",
		AssignedTo:  "ask",
	})
	bugs = append(bugs, shared.Bug{
		Name:        "name2",
		Description: "desc2",
		CreatedBy:   "ank2",
		AssignedTo:  "ask",
	})
	//Create(bugs)
}

func Test_Get(t *testing.T) {
	dbConfig := shared.DBConfig{
		Host:     "localhost",
		Port:     "3306",
		Username: "root",
		Password: "root",
	}
	db.ConfigureDB(shared.ApplicationProperties{
		DBConfig: dbConfig,
	})
	actual := Get(0)

	fmt.Println(actual)
}
