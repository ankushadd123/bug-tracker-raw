package repo

import (
	"com.bugTrack/api/db"
	"com.bugTrack/api/shared"
	"fmt"
	"time"
)


func Create(bug shared.BugRequest) shared.Bug{

	bugs := make([]shared.BugRequest, 0)
	bugs = append(bugs, bug)

	query := "INSERT INTO bug (name, description, created_by, assigned_to) VALUES "

	for index, bug := range bugs {
		query += fmt.Sprintf("('%s', '%s', '%d', '%d')", bug.Name, bug.Description,
			bug.CreatedBy, bug.AssignedTo)
		if index != len(bugs) - 1 {
			query += ","
		}
	}
	query += ";"
	result, err1 := db.Execute(query)

	if err1 != nil {
		return shared.Bug{
			BugOverview: shared.BugOverview{
				Id: 0,
			},
			CreatedBy:   0,
			CreatedAt:   "",
			UpdatedAt:   "",
		}
	}

	id, _ := result.LastInsertId()

	return getById(int(id))
}

func getById(id int) shared.Bug{
	query := fmt.Sprintf("SELECT * FROM bug WHERE id = %d;", id)

	row, _ := db.Select(query)

	var bug shared.Bug
	for row.Next() {
		row.Scan(&bug.Id, &bug.Name, &bug.Description, &bug.Status, &bug.CreatedBy,
			&bug.CreatedAt, &bug.UpdatedAt, &bug.AssignedTo)
	}
	return bug
}

func Get() []shared.Bug{
	query := "SELECT * FROM bug;"

	rows, err0 := db.Select(query)
	 if err0 != nil {
		 fmt.Println(err0)
		 return []shared.Bug{}
	 }

	var bugs []shared.Bug

	for rows.Next() {
	 var bug shared.Bug
	 rows.Scan(&bug.Id, &bug.Name, &bug.Description, &bug.Status, &bug.CreatedBy,
		 &bug.CreatedAt, &bug.UpdatedAt, &bug.AssignedTo)
	 bugs = append(bugs, bug)
	}
	return bugs
}

func UpdateStatus(bugId int, updatedStatus string) bool{
	query :=
		fmt.Sprintf("UPDATE bug SET status = '%s', updated_at = '%s' WHERE id = %d", updatedStatus, getUpdateTime(), bugId)

	return update(query)
}

func UpdateAssignee(bugId int, personId int) bool{
	query :=
		fmt.Sprintf("UPDATE bug SET assigned_to = %d, updated_at = '%s' WHERE id = %d", personId, getUpdateTime(), bugId)
	return update(query)
}

func UpdateBug(bug shared.BugOverview) bool{
	query :=
		fmt.Sprintf("UPDATE bug SET name = '%s', description = '%s', updated_at = '%s', assigned_to = %d WHERE id = %d",
			bug.Name, bug.Description, getUpdateTime(), bug.AssignedTo, bug.Id)
	return update(query)

}

func getUpdateTime() string {
	return time.Now().Format(time.RFC3339)
}

func update(query string) bool{
	_, err := db.Execute(query)

	if err != nil {
		fmt.Errorf("error while updating: %s", err)
		return false
	}
	return true
}

func DeleteBug(id int) bool {
	query := fmt.Sprintf("DELETE FROM bug WHERE id = %d;", id)
	rows, err := db.Execute(query)

	if err != nil {
		return false
	}
	effected, _ := rows.RowsAffected()

	if effected !=  int64(0) {
		return true
	}
	return false
}