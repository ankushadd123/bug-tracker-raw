package repo

import (
	"com.bugTrack/api/db"
	"com.bugTrack/api/shared"
)
import "fmt"

//func GetPerson(id int) {
//
//	query := fmt.Sprintf("SELECT id, name, role FROM person WHERE id = %d;", id)
//
//	row, error := db.Select(query)
//
//	if error != nil {
//		fmt.Errorf("some error occurred get person: %s", error)
//		return
//	}
//
//	for row.Next() {
//		var person shared.Person
//		row.Scan(&person.Id, &person.Name, &person.Role)
//		fmt.Println(person)
//	}
//}

func GetPeople() []shared.Person{

	query := "SELECT id, name, role FROM person;"

	rows, error := db.Select(query)

	var people []shared.Person

	if error != nil {
		fmt.Errorf("some error occurred while reading people: %s", error)
		return people
	}

	for rows.Next() {
		var person shared.Person

		rows.Scan(&person.Id, &person.Name, &person.Role)

		people = append(people, person)
	}

	return people
}


func CreatePerson(person shared.Person) (int, error) {

	query := fmt.Sprintf("INSERT INTO person(name) value ('%s');", person.Name)

	output, err := db.Execute(query)

	if err != nil {
		return 0, err
	}

	id, _ := output.LastInsertId()

	return int(id), nil
}

func GetPerson(id int) (shared.Person, error){
	query := fmt.Sprintf("SELECT * FROM person WHERE id = %d;", id)

	rows, err := db.Select(query)

	var person shared.Person

	if err != nil {
		return person, err
	}

	for rows.Next() {
		rows.Scan(&person.Id, &person.Name, &person.Role)
	}
	return person, nil
}

func UpdatePerson(person shared.Person) bool{
	query := fmt.Sprintf("UPDATE person SET name = '%s' WHERE id = %d;", person.Name, person.Id)

	_, err := db.Execute(query)

	if err != nil {
		return false
	}
	return true
}