import React, {useEffect} from 'react';
import './App.css';
import NavBar from "./components/nav/Navbar";
import {Outlet, useNavigate} from 'react-router-dom';

function App() {

    return (
       <div className="app-container">
           <NavBar/>
           <Outlet/>
       </div>
    );
}

export default App;

