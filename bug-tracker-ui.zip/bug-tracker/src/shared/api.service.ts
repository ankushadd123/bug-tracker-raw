import http from './http-client';
import {BugDetails, BugRequest, BugStatusRequest, Person, User} from "./model";

const BASE_URL = 'http://localhost:8082/api';

export const createBug = (bug: BugRequest): Promise<any> => {
    return http.post(BASE_URL + '/bug', bug);
};

export const getBugs = (): Promise<any> => {
    return http.get(BASE_URL + '/bug');
};

export const updateBugStatus = (bugStatusRequest: BugStatusRequest): Promise<any> => {
  return http.put(BASE_URL + '/bug/status', bugStatusRequest);
};

export const updateBugData = (request: BugDetails): Promise<any> => {
    request.description = request.description.replaceAll("'", "");
    return http.put(BASE_URL + '/bug', request);
};

export const deleteBug = (id: number): Promise<any> => {
    return http.delete(BASE_URL + '/bug/' + id);
};

export const createPerson = (person: Person): Promise<any> => {
    return http.post(BASE_URL + '/person', person);
};

export const createUser = (user: User): Promise<any> => {
    user.password = btoa(user.password);
    return http.post(BASE_URL + '/user', user);
};

export const updatePerson = (person: Person): Promise<any> => {
    return http.put(BASE_URL + '/person', person);
};

export const updateUser = (user: User): Promise<any> => {
    user.password = btoa(user.password);
    return http.put(BASE_URL + '/user', user);
};

export const getPerson = (id: number): Promise<any> => {
    return http.get(BASE_URL + '/person/' + id);
};

export const getUser = (id: number): Promise<any> => {
    return http.get(BASE_URL + '/user/v1/' + id);
};

export const getUserByUsername = (username: string): Promise<any> => {
    return http.get(BASE_URL + '/user/v2/' + username);
}

export function authenticate(username: string, password: string) {
    const config = { headers: {
            "Authorization": btoa(username + ":" + btoa(password))
        }}
    return http.post(BASE_URL + "/authenticate",null, config);
}

export function getPeople(): Promise<any> {
    return http.get(BASE_URL + "/people");
}