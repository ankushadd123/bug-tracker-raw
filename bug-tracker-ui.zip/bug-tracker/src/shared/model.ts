
export interface BugDetails {
    id: number;
    name: string;
    description: string;
    status: BugStatus; //
    assigned_to: number;
    created_by: number;
    created_at: string;
    updated_at: string;
}

export enum BugStatus {
    TO_DO = 'TO_DO',
    IN_PROGRESS = 'IN_PROGRESS',
    DONE = 'DONE'
}

export interface BugStatusRequest {
    id: number;
    status: BugStatus;
}

export interface BugRequest {
    name: string;
    description: string;
    assigned_to: number;
    created_by: number;
}

export interface DropdownList {
    type: DropdownType;
    items: DropdownItem[];
}

export interface DropdownItem {
    id: number;
    name: string;
}

export interface DropdownItemWrapper {
    type: DropdownType;
    item: DropdownItem;
}

export enum DropdownType {
    PERSON = 'PERSON',
    BUG = 'BUG'
}

export interface User {
    id?: number;
    username: string;
    email: string;
    password: string;
    personId?: number;
}

export interface Person {
    id?: number;
    name: string;
    role?: string;
}

export interface Assignee {
    id: number;
    name: string;
}