import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import { Routes, Route, BrowserRouter, Navigate } from 'react-router-dom';
import Login from "./components/login/Login";
import Pool from "./components/pool/Pool";
import Profile from "./components/profile/Profile";
import AboutUs from "./components/about-us/AboutUs";
import Success from "./components/success/Success";
import UserForm from "./components/user-form/UserForm";
import Error from "./components/error/Error";

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);
root.render(
    <BrowserRouter>
        <Routes>
            <Route path='' element={<App/>}>
                <Route path="home" element={<Pool/>}/>
                <Route path="profile" element={<Profile/>}>
                    <Route path="" element={<UserForm isNew={ false }/>}/>
                    <Route path="success" element={<Success/>}/>
                </Route>
                <Route path="about-us" element={<AboutUs/>}/>
                <Route path='' element={<Navigate to="/login"/>}>
                </Route>
            </Route>
            <Route path='login' element={<Login/>}/>
            <Route path='register' element={<UserForm  isNew={ true }/>}/>
            <Route path='register/success' element={<Success/>}/>
            <Route path='error' element={<Error/>}/>

            <Route path='*' element={<Login/>}/>
        </Routes>
    </BrowserRouter>
);