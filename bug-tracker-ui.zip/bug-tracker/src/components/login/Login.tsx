import { useState } from "react";
import './login.scss';
import * as api from "../../shared/api.service";
import {useNavigate} from "react-router-dom";

const Login = () => {

    const [ username, setUsername ] = useState("");
    const [ password, setPassword ] = useState("");
    const [ isAuthorized, setIsAuthorized ] = useState(true);

    const navigate = useNavigate();

    const authenticationHandler = () => {
        api.authenticate(username, password)
            .then((response) => {
                if (response.status === 200) {
                    localStorage.clear();
                    localStorage.setItem("username", response.data.username);
                    localStorage.setItem("password", response.data.password);
                    localStorage.setItem("userId", response.data.id);
                    localStorage.setItem("personId", response.data.personId);
                    navigate("/home");
                }
                setIsAuthorized(false);
                setUsername('');
                setPassword('');
            })
            .catch((error) => {
                setIsAuthorized(false);
                setUsername('');
                setPassword('');
            });
    };

  return (
      <>
          <form className="login-form">
              <input className="input-field" type="username" id="username" placeholder="Username" value={username}
                     onChange={(event) => {
                         if (!isAuthorized)
                             setIsAuthorized(true);
                         setUsername(event.target.value);
                     }}/>
              <input className="input-field" type="password" id="password" placeholder="Password" value={password}
                     onChange={(event) => {
                         if (!isAuthorized)
                             setIsAuthorized(true);
                         setPassword(event.target.value);
                     }}/>
              <div className={ `invalid-login ${ isAuthorized ? "invalid-login-hidden" : ""} `}>Invalid username, password</div>
              <input className="login-button" type="button" value="Login"
                     onClick={() => authenticationHandler()}/>
              <div className="register-container">
                  <a href="/register" >Register</a>
              </div>
          </form>
      </>
  );
};

export default Login;