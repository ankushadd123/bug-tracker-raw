import './profile.scss';
import { Outlet } from "react-router-dom";


const Profile = () => {

    return (
        <Outlet/>
    );
};

export default Profile;

