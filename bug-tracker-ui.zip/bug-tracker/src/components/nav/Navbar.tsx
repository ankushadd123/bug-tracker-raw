import {Link} from "react-router-dom";
import './navbar.scss';

const NavBar = () => {
    return (
        <>
            <nav className="nav">
                <Link className="nav-option-style nav-option" to="/home">Home</Link>
                <Link className="nav-option-style nav-option" to="/profile">User management</Link>
                <Link className="nav-option-style nav-option" to="/about-us">About</Link>
                <Link className="nav-option-style logout" to="/login">Logout</Link>
            </nav>
        </>
    );
}

export default NavBar;