const AboutUs = () => {
    return (
        <div>about us</div>
    );
};

export default AboutUs;