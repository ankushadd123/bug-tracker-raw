import './dropdown.scss';
import {DropdownItem, DropdownItemWrapper, DropdownList} from "../../shared/model";
import { FC, useState } from "react";

interface DropdownProps {
    list_: DropdownList,
    selectedItem_ : DropdownItem | undefined,
    disabled_: boolean,
    itemSelectedFunc_: Function
}

const Dropdown: FC<DropdownProps> = ({ list_, disabled_, selectedItem_, itemSelectedFunc_ }) => {

    const [ open, setOpen ] = useState(false);
    const [ selected, setSelected ] = useState<DropdownItem | undefined>(selectedItem_);

    const items: any[] = [];

    list_.items.forEach((item: DropdownItem) => {
            items.push(<div className="dropdown-list-item" key={ item.id } id={ "" + item.id }
                onClick={(event) => selectItemHandler(event)}>{ item.name }</div>);
    });

    const selectItemHandler = (event: any) => {
        const selectedItemId = Number(event.target.id);
        const selectedItem = list_.items.find(item => item.id === selectedItemId);
        if (selectedItem) {
            // set in header
            setSelected(selectedItem);
            // call to parent
            const itemWrapper: DropdownItemWrapper = { type: list_.type, item: selectedItem };
            itemSelectedFunc_(itemWrapper);
        }
        itemsHideShowHandler();
    };

    const itemsHideShowHandler = () => {
        if (disabled_) {
            return;
        }
        if (open) {
            setOpen(false);
            return;
        }
        setOpen(true);
    };

    return (
        <>
          <div className="dropdown-container">
                     <div className="dropdown-list-header" onClick={ itemsHideShowHandler }>
                         <div className="dropdown-list-header-name"
                         >{ selectedItem_ ? selectedItem_.name  :
                             (selected && (list_.items.find(item => item.id === selected.id)) !== undefined ? selected.name : 'Select item') }</div>
                         <div className="dropdown-list-header-symbol">
                             <img className="open-list-img" src={ require('../../assets/triangle.ico') } alt={'assignee'}/>
                         </div>
                     </div>
                     <div className={ open ? "dropdown-list-container" : "dropdown-list-container-hidden" }>{ items }</div>
          </div>
        </>

    );
};

export default Dropdown;