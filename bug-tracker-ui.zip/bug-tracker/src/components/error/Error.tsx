const Error = () => {
  return (
      <div>Some internal error, backend unavailable</div>
  );
};

export default Error;