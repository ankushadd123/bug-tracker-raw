import './card.scss';
import {Assignee} from "../../shared/model";

const Card = (props: any) => {

    function dragStart() {
        props.setVisibleCardId(props.bug.id);
    }

    const assignee = props.assignees ? props.assignees.find((person: Assignee) => person.id === props.bug.assigned_to) : undefined;
    const createdBy = props.assignees ? props.assignees.find((person: Assignee) => person.id === props.bug.created_by) : undefined;

    return (
        <div className={`${ props.visibleCardId === 0 ?
            "card card-layout" : "card card-layout card-hidden" }`}
             draggable="true"
             onDragStart={ dragStart }>
            <div className="card-header">
                <div className="card-content-wrapped">BT-{ props.bug.id }</div>
            </div>
            <div className="card-body">
                <div className="card-name-assignee">
                    <div className="card-name">{ props.bug.name }</div>
                    <div className="card-assigned-to">{ createdBy ? createdBy.name : '-' }</div>
                    <img className="card-assignee card-assignee-img" src={ require('./../../assets/person.ico') }/>

                </div>
                <div className={`card-description ${ props.bug.description && props.bug.description.length > 0 ? "" : "text-not-available"}`}
                >{ props.bug.description && props.bug.description.length > 0 ? props.bug.description :
                    "Description not added" }</div>
                <div  className="card-created-container">
                    <div className="card-created-by">{ assignee ? assignee.name : 0 }</div>
                    <div className="card-created-at">{ props.bug.created_at }</div>
                </div>
            </div>
        </div>
    );
};

export default Card;