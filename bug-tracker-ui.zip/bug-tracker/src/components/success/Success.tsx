import {useLocation, useNavigate} from "react-router-dom";
import './success.scss';

const Success = () => {

    const location = useLocation();
    const navigate = useNavigate();
    const currentLocation = location.pathname;

   const navigateToHome = () => {
       navigate("/home");
   };

    const navigateToLogin = () => {
        navigate("/login");
    };

    const handleClick = () => {
        currentLocation.includes("/register/") ? navigateToLogin() : navigateToHome();
    };

    return (
        <div className="success-container">
            <div className="success-text">Success!!</div>
            <input type="button" value={ currentLocation.includes("/register/") ? "Login" : "Home" } className="success-btn"
                   onClick={ handleClick }/>
        </div>
    );
};

export default Success;