import './pool.scss';
import Bug from "../bug/Bug";
import SwimLane from "../swimlane/SwimLane";
import {useEffect, useState} from "react";
import {Assignee, BugDetails, BugRequest, BugStatus, Person} from "../../shared/model";
import * as api from "../../shared/api.service";
import {useNavigate} from "react-router-dom";

const Pool = () => {

    const [ allBugs, setAllBugs ] = useState<BugDetails[]>([]);
    const [ visibleCardId, setVisibleCardId ] = useState(0);
    const [ assignees, setAssignees ] = useState<Assignee[]>();

    const navigate = useNavigate();


    useEffect(() => {
        const getAllBugs = () => getBugsHandler().then(response => {
            if (response.code === 'ERR_NETWORK') {
                navigate("/error");
            }
            setAllBugs(response.data);
        });

        const getAllAssignee = () => {
            getPeopleHandler().then(response => {

                //code: "ERR_NETWORK"
                if (response.code === 'ERR_NETWORK') {
                    navigate("/error");
                }

                if (response.status === 200) {
                    const tempAssignees: Assignee[] = [];
                    response.data.forEach((person: Person) => {
                        if (person.id) {
                            const assignee: Assignee = { id: person.id, name: person.name };
                            tempAssignees.push(assignee);
                        }
                    });
                    setAssignees(tempAssignees);
                }
            });
        }
        getAllAssignee();
        getAllBugs();
    }, [ setAllBugs, setAssignees ]);

    const createNewBug = (bug: BugRequest) => {
        api.createBug(bug).then(response => {
            if (response) {
                const tempBugs = [];
                if (allBugs) {
                    allBugs.forEach(bug =>
                        tempBugs.push(bug)
                    );
                    tempBugs.push(response.data);
                    setAllBugs(tempBugs);
                }
            }
        });
    };

    const setCardsVisibility = (selectedCardId: number) => {
        setVisibleCardId(selectedCardId);
    }

    const updateBugStatus = (bugId: number, updatedStatus: BugStatus) => {
        updateBugStatusHandler(bugId, updatedStatus).then(response => {
            if (response.data) {
                const tempBugs = updateBugStatusSuccessHandler(allBugs, bugId, updatedStatus);
                setAllBugs(tempBugs);
            }
        });
    };

    const updateBugData = (id: number, name: string, description: string, assignedTo: number) => {
        updateBugDataHandler(id, name, description, assignedTo).then(response => {
            if (response.data) {
                const tempBugs = updateBugDataHandlerSuccess(allBugs, id, name, description, assignedTo);
                setAllBugs(tempBugs);
            }
        });
    }

    const deleteBug = (id: number) => {
        deleteBugHandler(id).then(response => {
            if (response && response.data) {
                const tempBugs = deleteBugHandlerSuccess(allBugs, id);
                setAllBugs(tempBugs);
            }
        });
    };



    return (
        <div className="pool-container">
            <SwimLane bugs={ allBugs } visibleCardId={ visibleCardId } setVisibleCardId={ setCardsVisibility }
                      updateBugStatus={ updateBugStatus } assignees={ assignees }/>
            <Bug createNewBug={ createNewBug } bugs={ allBugs } updateBugData={ updateBugData } deleteBug={ deleteBug }
                 assignees={ assignees }/>
        </div>);
};

export default Pool;


const getBugsHandler = () => {
    return api.getBugs();
};

const updateBugStatusHandler = (id: number, status: BugStatus) => {
    return api.updateBugStatus({ id, status });
};

const updateBugDataHandler = (id: number, name: string, description: string, assignedTo: number) => {
    return api.updateBugData({ id, name, description, assigned_to: assignedTo } as BugDetails);
};

const updateBugDataHandlerSuccess = (allBugs: BugDetails[], bugId: number, name: string, description: string, assignedTo: number) => {
    const tempBugs: BugDetails[] = [];
    bugId = Number(bugId);
    allBugs.forEach(bug => {
        if (bug.id === bugId) {
            bug.name = name;
            bug.description = description;
            bug.assigned_to = assignedTo;
        }
        tempBugs.push(bug);
    });
    return tempBugs;
};

const updateBugStatusSuccessHandler =
    (allBugs: BugDetails[], bugId: number, updatedStatus: BugStatus) => {
    const tempBugs: BugDetails[] = [];
    allBugs.forEach(bug => {
        if (bug.id === bugId) {
            bug.status = updatedStatus;
        }
        tempBugs.push(bug);
    });
    return tempBugs;
};

const deleteBugHandler = (id: number) => {
    return api.deleteBug(id);
};


const deleteBugHandlerSuccess = (allBugs: BugDetails[], id: number) => {
    const tempBugs: BugDetails[] = [];
    id = Number(id);
    allBugs.forEach(bug => {
        if (bug.id !== id) {
            tempBugs.push(bug);
        }
    });
    return tempBugs;
};

const getPeopleHandler = () => {
    return api.getPeople();
};