import './swimlane.scss';
import {BugDetails, BugStatus} from "../../shared/model";
import Card from "../card/Card";

const SwimLane = (props: any) => {

    const toDoBugs: any[] = [];
    const inProgressBugs: any[] = [];
    const doneBugs: any[] = [];

    props.bugs.forEach((bug: BugDetails) => {
        if (bug.status === BugStatus.TO_DO) {
            toDoBugs.push(getCard(bug, props));
        }
        if (bug.status === BugStatus.IN_PROGRESS) {
            inProgressBugs.push(getCard(bug, props));
        }
        if (bug.status === BugStatus.DONE) {
            doneBugs.push(getCard(bug, props));
        }
    });

    const changeSwimLane = (bugId: number, updatedStatus: BugStatus) => {
        props.updateBugStatus(bugId, updatedStatus);
    }

    function drop(event: any, status: BugStatus) {
        changeSwimLane(props.visibleCardId, status);
        props.setVisibleCardId(0);
    }

    function dragOver(event: any) {
        event.preventDefault();
    }

    return (
        <div className="swimlane-container">
            <div className="swimlane-header">
                <div className="swimlane-header-item">To do</div>
                <div className="swimlane-header-item">In progress</div>
                <div className="swimlane-header-item">Done</div>
            </div>
            <div className="swimlane-content">
                <div className="swimlane-content-item"
                     onDrop={ (event) => drop(event, BugStatus.TO_DO) }
                     onDragOver={ (event) => dragOver(event) }>{ toDoBugs }</div>
                <div className="swimlane-content-item swimlane-content-item-middle"
                     onDrop={ (event) => drop(event, BugStatus.IN_PROGRESS) }
                     onDragOver={ (event) => dragOver(event) }>{ inProgressBugs }</div>
                <div className="swimlane-content-item"
                     onDrop={ (event) => drop(event, BugStatus.DONE) }
                     onDragOver={ (event) => dragOver(event) }>{ doneBugs }</div>
            </div>
        </div>
    );
}

export default SwimLane;

const getCard = (bug: BugDetails, props: any ) => {
    return <Card bug={bug} key={bug.id} visibleCardId={props.visibleCardId}
                 setVisibleCardId={props.setVisibleCardId} assignees={ props.assignees }/>
};