import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";
import {Person, User} from "../../shared/model";
import * as api from "../../shared/api.service";

const UserForm = (props: any) => {

    const [ name, setName ] = useState('');
    const [ username, setUsername ] = useState('');
    const [ email, setEmail ] = useState('');
    const [ password, setPassword ] = useState('');
    const [ personId, setPersonId ] = useState(0);
    const [ userId, setUserId ] = useState(0);

    const navigate = useNavigate();

    useEffect(() => {
        const initiateFields = () => {
            if (!props.isNew) {
                const credentials = getUserFromLocalStorage();
                if (credentials !== null && credentials.username) {
                    api.getUserByUsername(credentials.username)
                        .then(response => {
                            if (response.status === 200) {
                                const user: User = response.data;
                                if (user.id) {
                                    api.getPerson(user.id).then(response => {
                                        if (response.status === 200) {
                                            const person: Person = response.data;
                                            setName(person.name);
                                            setEmail(user.email);
                                            setPassword(atob(user.password));
                                            setUsername(user.username);
                                            if (person.id) setPersonId(person.id);
                                            if (user.id) setUserId(user.id);
                                        }
                                    });
                                }
                            }
                        });
                }
            }
        };
        initiateFields();
    }, [ setName, setUsername, setEmail, setPassword, setPersonId, setUserId ]);

    const submit = () => {
        const user: User = { email, password, username };
        const person: Person = { name };
        submitHandler(person, user, navigate);
    };

    const update = () => {
        const user: User = { email, password, username, id: userId };
        const person: Person = { name, id: personId };
        updateHandler(person, user, navigate);
    };

    return (
        <form className="profile-container">
            <label className="profile-label">Name</label>
            <input type="text" id="name" className="profile-input" value={name}
                   onChange={(event) => setName(event.target.value) }/>
            <label className="profile-label">Username</label>
            <input type="text" id="username" className="profile-input" value={username} disabled={ !props.isNew }
                   onChange={(event) => setUsername(event.target.value) }/>
            <label className="profile-label">Email</label>
            <input type="text" id="email" className="profile-input" value={email}
                   onChange={(event) => setEmail(event.target.value) }/>
            <label className="profile-label">Password</label>
            <input type="password" id="password" className="profile-input" value={password}
                   placeholder="minimum 6 characters"
                   onChange={(event) => setPassword(event.target.value) }/>

            <input type="button" value={ props.isNew ? "Submit" : "Update" } className="submit-btn"
                   disabled={ (name.length === 0 || email.length === 0 || username.length === 0 || password.length === 0)
                       || (password.length < 6) }
                   onClick={ props.isNew ? submit : update }/>
        </form>
    );

};

export default UserForm;

const submitHandler = (person: Person, user: User, navigate: any) => {
    createPerson(person, user, navigate);
};

const updateHandler = (person: Person, user: User, navigate: any) => {
    updatePerson(person, user, navigate);
};

const createPerson = (person: Person, user: User, navigate: any) => {
    api.createPerson(person).then(response => {
        if (response.status === 201) {
            user.personId = response.data;
            createUser(user, navigate);
        }
    });
};

const updatePerson = (person: Person, user: User, navigate: any) => {
    api.updatePerson(person).then(response => {
        if (response.status === 200) {
            // user.personId = response.data;
            updateUser(user, navigate);
        }
    });
};

const createUser = (user: User, navigate: any) => {
    api.createUser(user).then(response => {
        if (response.status === 201) {
            createUserSuccessHandler(navigate);
        }
    });
};

const updateUser = (user: User, navigate: any) => {
    api.updateUser(user).then(response => {
        if (response.status === 200) {
            updateUserSuccessHandler(navigate);
        }
    });
};

const updateUserSuccessHandler = (navigate: any) => {
    navigate('/profile/success');
};

const createUserSuccessHandler = (navigate: any) => {
    navigate('/register/success');
};

const getUserFromLocalStorage = () => {
  return { username: localStorage.getItem('username') }
};