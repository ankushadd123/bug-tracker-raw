import './bug.scss';
import {useState} from "react";
import {
    Assignee,
    BugDetails,
    BugRequest,
    DropdownItem,
    DropdownItemWrapper,
    DropdownList,
    DropdownType
} from "../../shared/model";
import Dropdown from "../drop-down/Dropdown";

const Bug = (props: any) => {

    const [ toEdit, setToEdit ] = useState(false);
    const [ toAdd, setToAdd ] = useState(true);

    const [ name, setName ] = useState('');
    const [ description, setDescription ] = useState('');

    // ######################################   Important info    ###############################################

    // selection assignee in d.d. is managed by this component
    // selection bug in d.d. is independent of this component

    // #########################################################################################################

    const [ selectedBug, setSelectedBug ] = useState<BugDetails>();
    const [ selectedItemInAssigneeDropdown, setSelectedItemInAssigneeDropdown ] = useState<DropdownItem>();

    const bugDropdown = { type: DropdownType.BUG, items: bugDropdownItemMapper(props.bugs) }
    const assigneeDropdown: DropdownList = { type: DropdownType.PERSON, items: assigneeDropdownMapper(props.assignees) };

    // #########################################    add, update    #################################################

    const addNewBug = () => {
      const newBug: BugRequest = { name, description, assigned_to: assignedTo(), created_by: createdBy() };
      props.createNewBug(newBug);
      setName('');
      setDescription('');
    };

    const updateBug = () => {
        if (selectedBug && selectedItemInAssigneeDropdown) {
            props.updateBugData(selectedBug.id, name, description, selectedItemInAssigneeDropdown.id);
        }
    };

    // #########################################    delete    #################################################

    const deleteBug = () => {
        if (selectedBug) {
            props.deleteBug(selectedBug.id);
            setSelectedBug(undefined);
            setSelectedItemInAssigneeDropdown(undefined);
            setName('');
            setDescription('');
        }
    }

    // #########################################    tab selection for add, edit    #################################################

    const handleAddTab = () => {
        setToAdd(true);
        setToEdit(false);
        setName('');
        setDescription('');
    };

    const handleUpdateTab = () => {
        setToAdd(false);
        setToEdit(true);
        setName('');
        setDescription('');
        setSelectedItemInAssigneeDropdown(undefined);
        setSelectedBug(undefined);
    };

    // ################################   bug selected, assignee selected   ###################################

    const dropdownItemSelectedHandler = (itemWrapper: DropdownItemWrapper) => {
        if (!itemWrapper) {
            return;
        }
        const selectedDropdownItem = itemWrapper.item;
        if (itemWrapper.type === 'BUG') {
            if (selectedDropdownItem) {
                const tempBugSelected = props.bugs.find((bug: BugDetails) => bug.id === selectedDropdownItem.id);
                setSelectedBug(tempBugSelected);
                if (tempBugSelected) {
                    setName(tempBugSelected.name);
                    setDescription(tempBugSelected.description);
                    // set assignee
                    selectAssigneeInDropdown(tempBugSelected);
                }
            }
        }
        if (itemWrapper.type === 'PERSON') {
            if (selectedDropdownItem) {
                const tempAssigneeSelected = assigneeDropdown.items.find((item: DropdownItem) => item.id === selectedDropdownItem.id);
                if (tempAssigneeSelected) {
                    setSelectedItemInAssigneeDropdown(tempAssigneeSelected);
                }
            }
        }
    };

    const selectAssigneeInDropdown = (selectedBug: BugDetails) => {
        const assignedToId = selectedBug.assigned_to;
        const tempSelectedItemInAssigneeDropdown = assigneeDropdown.items.find(item => item.id === assignedToId );
        if (tempSelectedItemInAssigneeDropdown) {
            setSelectedItemInAssigneeDropdown(tempSelectedItemInAssigneeDropdown);
        }
    };

    // ################################   ************************   ###################################


    return (
        <div className="bug-container">
            <div className="bug-nav">
                <div className={`bug-nav-tab ${ toAdd ? 'bug-nav-tab-selected' : ''}`}
                     onClick={() => handleAddTab()}>Create</div>
                <div className={`bug-nav-tab ${ toEdit ? 'bug-nav-tab-selected' : '' }`}
                     onClick={() => handleUpdateTab()}>Edit</div>
            </div>
            <form className='bug-form-container'>
                <div className="bug-input-container">
                    <label className="bug-input-item bug-form-label">Name</label>
                    <input type="text" id="name" className="bug-form-input" value={name}
                               onChange={(event) => setName(event.target.value)}
                                disabled={ toEdit && !selectedBug }/>
                </div>
                <div className="bug-input-container">
                    <label className="bug-input-item bug-form-label">Description</label>
                    <textarea id="description" className="bug-form-input bug-form-input-textarea" value={description}
                            onChange={(event) => setDescription(event.target.value)}
                              disabled={ toEdit && !selectedBug }/>
                </div>

                <>
                { toEdit ? <div className="bug-input-container">
                                <label className="bug-input-item bug-form-label">Assignee</label>
                                <Dropdown list_={ assigneeDropdown } selectedItem_={ selectedItemInAssigneeDropdown }
                                          itemSelectedFunc_={ dropdownItemSelectedHandler } disabled_={ !selectedBug } />
                            </div>
                         : null
                }

                </>
                <>{ !toAdd ? <div className="bug-input-container">
                        <label className="bug-input-item bug-form-label select-bug-label">Select bug</label>
                        <Dropdown list_={ bugDropdown } selectedItem_= { undefined }
                                  disabled_={ false } itemSelectedFunc_={ dropdownItemSelectedHandler }/>
                    </div> : null}
                </>

                { toAdd ?
                    <input type="button" value="Add" className='bug-form-btn bug-form-btn-add'
                           onClick={() => addNewBug()} disabled={ (!name || name.length === 0) }/>
                        :
                    <> <input type="button" value="Update" className='bug-form-btn bug-form-btn-edit' onClick={ updateBug }
                              disabled =
                                  { !(selectedBug &&
                                      (selectedBug.name !== name || selectedBug.description !== description
                                        || (selectedItemInAssigneeDropdown &&
                                              selectedItemInAssigneeDropdown.id !== selectedBug.assigned_to) )) }/>
                        <input type="button" value="Delete" className='bug-form-btn bug-form-btn-delete'
                               disabled={ !selectedBug } onClick={() => deleteBug()}/>
                    </>
                }

            </form>
        </div>
    );
};

export default Bug;

const bugDropdownItemMapper = (bugs: BugDetails[]) => {
    const dropdownItems: DropdownItem[] = [];
    bugs.forEach(bug => {
        dropdownItems.push({ name: 'BT-' + bug.id, id: bug.id });
    });
    return dropdownItems;
};

const assigneeDropdownMapper = (people: Assignee[]) => {
    const dropdownItems: DropdownItem[] = [];
    if (people) {
        people.forEach(person => {
            dropdownItems.push({name: person.name, id: person.id});
        });
    }
    return dropdownItems;
}

const createdBy = (): number => {
    return Number(localStorage.getItem("personId"));
};

const assignedTo = (): number => {
    return Number(localStorage.getItem("personId"));
};